<?php
//if ( !defined( 'WGR_APP_PATH' ) )die( 'No direct script access allowed #' . basename( __FILE__ . ':' . __LINE__ ) );

/*
* Cách sử dụng:
Wgr::$eb->PostControllersWgr->functionName();
*/

class PostControllersWgr extends ControllersWgr {
    function __construct() {
        parent::__construct();
    }
}