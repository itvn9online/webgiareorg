<?php

/*
 * Thêm đoạn code này vào file function trong child-theme flatsome
require dirname( dirname( __DIR__ ) ) . '/webgiareorg/functions.php';
 */

/*
 * Do đoạn code viewport của flatsome chưa đạt chuẩn điểm của google page speed -> cần phải chỉnh lại
 */
// Remove Header Viewport Meta 
function remove_flatsome_viewport_meta() {
    remove_action( 'wp_head', 'flatsome_viewport_meta', 1 );
}
add_action( 'init', 'remove_flatsome_viewport_meta', 15 );

// thuộc tính này để xác định code áp dụng cho plugin wocomerce -> sẽ có 1 số tính năng bổ sung cho nó
if ( class_exists( 'WooCommerce' ) ) {
    define( 'WGR_FOR_WOOCOMERCE', true );
    //var_dump( WGR_FOR_WOOCOMERCE );
}

//
define( 'WGR_PATH', __DIR__ . '/' );
//echo WGR_PATH . '<br>' . "\n";
define( 'WGR_APP_PATH', __DIR__ . '/app/' );
//echo WGR_APP_PATH . '<br>' . "\n";
define( 'WGR_LIB_PATH', WGR_APP_PATH . 'Libraries/' );
//echo WGR_LIB_PATH . '<br>' . "\n";


// global static class
class Wgr {
    public static $eb = [];
}

// autoload MVC file
$arr_wgr_autoload = [
    // autoload system file (main file)
    'system',
    // autoload model
    'app/Models',
    // autoload controllers
    'app/Controllers',
];

foreach ( $arr_wgr_autoload as $v ) {
    foreach ( glob( __DIR__ . '/' . $v . '/*.php' ) as $filename ) {
        //echo $filename . '<br>' . "\n";
        include $filename;

        //
        $classNoExt = basename( $filename, '.php' );
        //echo $classNoExt . '<br>' . "\n";
        Wgr::$eb[ $classNoExt ] = new $classNoExt();
    }
}

// autoload library and conts file
foreach ( glob( WGR_LIB_PATH . '*.php' ) as $filename ) {
    //echo $filename . '<br>' . "\n";
    include_once $filename;
}

// conver to object
print_r( Wgr::$eb );
Wgr::$eb = ( object )Wgr::$eb;
print_r( Wgr::$eb );

/*
 * END
 */